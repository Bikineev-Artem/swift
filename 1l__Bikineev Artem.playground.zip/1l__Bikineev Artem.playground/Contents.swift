import UIKit
var x1  = 0
var x2  = 0
var discrim = 0
let equ = "(x^2)-2x+11=0"
let a = 3
let b = -2
let c = 11
  discrim = b * b - 4 * a * c
if discrim > 0 {
     x1 = (-b + sqrt(discrim)) / (2 * a)
     x2 = (-b - sqrt(discrim)) / (2 * a)
    print ("X1 = \(x1); X2 = \(x2)")
} else if discrim == 0 {
     x1 = (-b + sqrt(discrim)) / (2 * a)
    print ("X1 = X2 = \(x1)")
} else {
    print ("Нет корней")

}
